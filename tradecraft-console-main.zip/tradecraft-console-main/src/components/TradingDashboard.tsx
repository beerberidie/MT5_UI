import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  LineChart, 
  Settings, 
  Wifi, 
  WifiOff,
  Menu,
  X,
  DollarSign,
  Target,
  Clock,
  Activity
} from 'lucide-react';

// Trading Platform Configuration
declare global {
  interface Window {
    CONFIG: {
      API_BASE: string;
      REFRESH_INTERVAL: number;
      CONNECTION_TIMEOUT: number;
      MAX_RETRIES: number;
    };
    AUGMENT_API_KEY?: string;
    getAuthHeaders: () => Record<string, string>;
  }
}

interface AccountInfo {
  balance: number;
  equity: number;
  margin: number;
  freeMargin: number;
  marginLevel: number;
}

interface Position {
  ticket: number;
  symbol: string;
  type: string;
  volume: number;
  openPrice: number;
  currentPrice: number;
  profit: number;
  swap: number;
  commission: number;
}

interface Symbol {
  symbol: string;
  bid: number;
  ask: number;
  spread: number;
  change: number;
  changePercent: number;
}

const TradingDashboard: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState('market');
  const [analysisTab, setAnalysisTab] = useState('chart');
  const [activityTab, setActivityTab] = useState('deals');
  const [connectionStatus, setConnectionStatus] = useState(true);
  const [analysisControlsExpanded, setAnalysisControlsExpanded] = useState(true);
  
  // Data states
  const [account, setAccount] = useState<AccountInfo | null>(null);
  const [positions, setPositions] = useState<Position[]>([]);
  const [symbols, setSymbols] = useState<Symbol[]>([]);
  const [prioritySymbols, setPrioritySymbols] = useState<Symbol[]>([]);

  // Connection status monitoring
  useEffect(() => {
    const checkConnection = () => {
      fetch(`${window.CONFIG?.API_BASE || 'http://127.0.0.1:5001'}/api/account`, {
        headers: window.getAuthHeaders?.() || {},
        signal: AbortSignal.timeout(window.CONFIG?.CONNECTION_TIMEOUT || 10000)
      })
        .then(() => setConnectionStatus(true))
        .catch(() => setConnectionStatus(false));
    };

    checkConnection();
    const interval = setInterval(checkConnection, window.CONFIG?.REFRESH_INTERVAL || 5000);
    return () => clearInterval(interval);
  }, []);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const formatCurrency = (value: number, decimals = 2) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  return (
    <div className="min-h-screen bg-background text-text-primary">
      {/* Header */}
      <header className="h-header bg-panel border-b border-border flex items-center justify-between px-4 relative z-50">
        <div className="flex items-center gap-4">
          <button
            onClick={toggleSidebar}
            className="p-2 hover:bg-secondary rounded-md transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu className="w-4 h-4" />
          </button>
          <h1 className="text-lg font-semibold text-text-primary">Trade Agent MT5</h1>
        </div>
        
        {/* Account Info Header */}
        <div className="flex items-center gap-6 text-sm">
          <div className="flex items-center gap-1">
            <span className="text-text-secondary">Balance:</span>
            <span id="header-balance" className="font-mono tabular-nums font-medium">
              ${formatCurrency(account?.balance || 0)}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-text-secondary">Equity:</span>
            <span id="header-equity" className="font-mono tabular-nums font-medium">
              ${formatCurrency(account?.equity || 0)}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-text-secondary">Margin:</span>
            <span id="header-margin" className="font-mono tabular-nums font-medium">
              ${formatCurrency(account?.margin || 0)}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-text-secondary">Free:</span>
            <span id="header-free-margin" className="font-mono tabular-nums font-medium">
              ${formatCurrency(account?.freeMargin || 0)}
            </span>
          </div>
          
          {/* Connection Status */}
          <div className="flex items-center gap-2">
            <div
              id="connection-status"
              className={`w-2 h-2 rounded-full ${connectionStatus ? 'bg-status-online' : 'bg-status-offline'}`}
            />
            <span id="connection-text" className={connectionStatus ? 'status-online' : 'status-offline'}>
              {connectionStatus ? 'Connected' : 'Disconnected'}
            </span>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-3.5rem)]">
        {/* Sidebar */}
        <aside 
          className={`bg-sidebar border-r border-sidebar-border transition-all duration-300 ${
            sidebarCollapsed ? 'w-sidebar-collapsed' : 'w-sidebar'
          } flex flex-col`}
        >
          {/* Navigation */}
          <nav className="p-3">
            <div className="space-y-1">
              <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md bg-sidebar-item-active text-primary text-sm font-medium">
                <TrendingUp className="w-4 h-4" />
                {!sidebarCollapsed && 'Dashboard'}
              </button>
              <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-sidebar-item-hover text-text-secondary text-sm">
                <BarChart3 className="w-4 h-4" />
                {!sidebarCollapsed && 'Analysis'}
              </button>
              <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-sidebar-item-hover text-text-secondary text-sm">
                <Settings className="w-4 h-4" />
                {!sidebarCollapsed && 'Settings'}
              </button>
            </div>
          </nav>

          {/* Priority Symbols */}
          {!sidebarCollapsed && (
            <div className="flex-1 p-3">
              <h3 className="text-xs font-medium text-text-secondary uppercase tracking-wider mb-3">Priority Symbols</h3>
              <div id="priority-symbols-list" className="space-y-1">
                {prioritySymbols.slice(0, 8).map((symbol, index) => (
                  <div key={symbol.symbol} className="flex items-center justify-between p-2 rounded hover:bg-sidebar-item-hover text-xs">
                    <span className="font-medium">{symbol.symbol}</span>
                    <div className="text-right">
                      <div className="font-mono tabular-nums">{formatCurrency(symbol.bid, 5)}</div>
                      <div className={`font-mono tabular-nums ${symbol.change >= 0 ? 'value-positive' : 'value-negative'}`}>
                        {formatPercent(symbol.changePercent)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mini Market Watch for collapsed state */}
          {sidebarCollapsed && (
            <div id="sidebar-mini-watch-list" className="flex-1 p-2">
              <div className="space-y-2">
                {prioritySymbols.slice(0, 4).map((symbol) => (
                  <div key={symbol.symbol} className="text-center">
                    <div className="text-xs font-medium truncate">{symbol.symbol}</div>
                    <div className={`text-xs font-mono tabular-nums ${symbol.change >= 0 ? 'value-positive' : 'value-negative'}`}>
                      {symbol.change >= 0 ? '+' : ''}{symbol.changePercent.toFixed(1)}%
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Order Entry Section */}
          <div className="border-b border-border bg-panel">
            <div className="p-4">
              {/* Order Type Tabs */}
              <div className="flex gap-1 mb-4">
                <button
                  onClick={() => setActiveTab('market')}
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'market'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary-hover'
                  }`}
                >
                  Market Order
                </button>
                <button
                  onClick={() => setActiveTab('pending')}
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'pending'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary-hover'
                  }`}
                >
                  Pending Order
                </button>
              </div>

              {/* Order Entry Form */}
              <div className="grid grid-cols-12 gap-4 items-end">
                <div className="col-span-2">
                  <label htmlFor="sym" className="block text-xs font-medium text-text-secondary mb-1">Symbol</label>
                  <select id="sym" className="trading-input w-full">
                    <option>EURUSD</option>
                    <option>GBPUSD</option>
                    <option>USDJPY</option>
                    <option>AUDUSD</option>
                  </select>
                </div>
                
                <div className="col-span-1">
                  <label htmlFor="volume" className="block text-xs font-medium text-text-secondary mb-1">Volume (lots)</label>
                  <input
                    type="number"
                    id="volume"
                    className="trading-input w-full"
                    placeholder="0.01"
                    step="0.01"
                    min="0.01"
                  />
                </div>
                
                <div className="col-span-1">
                  <label htmlFor="deviation" className="block text-xs font-medium text-text-secondary mb-1">Deviation (pips)</label>
                  <input
                    type="number"
                    id="deviation"
                    className="trading-input w-full"
                    placeholder="10"
                    min="0"
                  />
                </div>
                
                <div className="col-span-1">
                  <label htmlFor="sl" className="block text-xs font-medium text-text-secondary mb-1">Stop Loss</label>
                  <input
                    type="number"
                    id="sl"
                    className="trading-input w-full"
                    placeholder="0.0000"
                    step="0.0001"
                  />
                </div>
                
                <div className="col-span-1">
                  <label htmlFor="tp" className="block text-xs font-medium text-text-secondary mb-1">Take Profit</label>
                  <input
                    type="number"
                    id="tp"
                    className="trading-input w-full"
                    placeholder="0.0000"
                    step="0.0001"
                  />
                </div>
                
                <div className="col-span-3 flex gap-2">
                  <button id="buy-btn" className="btn-trading-success flex-1 flex items-center justify-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    BUY
                  </button>
                  <button id="sell-btn" className="btn-trading-danger flex-1 flex items-center justify-center gap-2">
                    <TrendingDown className="w-4 h-4" />
                    SELL
                  </button>
                </div>
                
                <div className="col-span-3">
                  <div id="order-output" className="text-xs text-text-secondary min-h-[20px]">
                    Ready to trade
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Market Analysis & Positions Layout */}
          <div className="flex-1 flex overflow-hidden">
            {/* Market Analysis - Center */}
            <div className="flex-1 flex flex-col border-r border-border">
              {/* Analysis Tabs */}
              <div className="border-b border-border bg-panel px-4 py-2">
                <div className="flex items-center justify-between">
                  <div className="flex gap-1">
                    <button
                      onClick={() => setAnalysisTab('chart')}
                      className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                        analysisTab === 'chart'
                          ? 'bg-primary text-primary-foreground'
                          : 'text-text-secondary hover:text-text-primary hover:bg-secondary'
                      }`}
                    >
                      Chart
                    </button>
                    <button
                      onClick={() => setAnalysisTab('bars')}
                      className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                        analysisTab === 'bars'
                          ? 'bg-primary text-primary-foreground'
                          : 'text-text-secondary hover:text-text-primary hover:bg-secondary'
                      }`}
                    >
                      Bars
                    </button>
                    <button
                      onClick={() => setAnalysisTab('ticks')}
                      className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                        analysisTab === 'ticks'
                          ? 'bg-primary text-primary-foreground'
                          : 'text-text-secondary hover:text-text-primary hover:bg-secondary'
                      }`}
                    >
                      Ticks
                    </button>
                    <button
                      onClick={() => setAnalysisTab('stats')}
                      className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                        analysisTab === 'stats'
                          ? 'bg-primary text-primary-foreground'
                          : 'text-text-secondary hover:text-text-primary hover:bg-secondary'
                      }`}
                    >
                      Stats
                    </button>
                  </div>
                  
                  <button
                    onClick={() => setAnalysisControlsExpanded(!analysisControlsExpanded)}
                    className="p-1.5 hover:bg-secondary rounded transition-colors"
                    aria-label="Toggle analysis controls"
                  >
                    <Settings id="controls-toggle-icon" className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Analysis Controls Panel */}
              {analysisControlsExpanded && (
                <div id="analysis-controls-panel" className="border-b border-border bg-panel p-4">
                  <div className="grid grid-cols-6 gap-4 items-end">
                    <div>
                      <label htmlFor="histSymbol" className="block text-xs font-medium text-text-secondary mb-1">Symbol</label>
                      <select id="histSymbol" className="trading-input w-full">
                        <option>EURUSD</option>
                        <option>GBPUSD</option>
                        <option>USDJPY</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="histTimeframe" className="block text-xs font-medium text-text-secondary mb-1">Timeframe</label>
                      <select id="histTimeframe" className="trading-input w-full">
                        <option>M1</option>
                        <option>M5</option>
                        <option>M15</option>
                        <option>H1</option>
                        <option>H4</option>
                        <option>D1</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="histDateFrom" className="block text-xs font-medium text-text-secondary mb-1">From Date</label>
                      <input type="date" id="histDateFrom" className="trading-input w-full" />
                    </div>
                    <div>
                      <label htmlFor="histDateTo" className="block text-xs font-medium text-text-secondary mb-1">To Date</label>
                      <input type="date" id="histDateTo" className="trading-input w-full" />
                    </div>
                    <div>
                      <label htmlFor="histCount" className="block text-xs font-medium text-text-secondary mb-1">Count</label>
                      <input type="number" id="histCount" className="trading-input w-full" placeholder="100" />
                    </div>
                    <div>
                      <button className="btn-secondary w-full">Load Data</button>
                    </div>
                  </div>
                </div>
              )}

              {/* Analysis Content */}
              <div className="flex-1 p-4 overflow-auto">
                {analysisTab === 'chart' && (
                  <div className="h-full bg-card rounded-lg border border-border flex items-center justify-center">
                    <div className="text-center text-text-muted">
                      <LineChart className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Chart view will be rendered here</p>
                    </div>
                  </div>
                )}
                
                {analysisTab === 'bars' && (
                  <div className="h-full">
                    <div className="trading-panel h-full">
                      <div className="trading-header">
                        <h3 className="font-medium">Historical Bars</h3>
                      </div>
                      <div className="trading-content">
                        <div className="overflow-auto">
                          <table id="historical-bars-table" className="trading-table">
                            <thead>
                              <tr>
                                <th>Time</th>
                                <th>Open</th>
                                <th>High</th>
                                <th>Low</th>
                                <th>Close</th>
                                <th>Volume</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td colSpan={6} className="text-center text-text-muted py-8">
                                  No data available. Use controls above to load historical bars.
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {analysisTab === 'ticks' && (
                  <div className="h-full bg-card rounded-lg border border-border flex items-center justify-center">
                    <div className="text-center text-text-muted">
                      <Activity className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Tick data will be displayed here</p>
                    </div>
                  </div>
                )}
                
                {analysisTab === 'stats' && (
                  <div className="h-full bg-card rounded-lg border border-border flex items-center justify-center">
                    <div className="text-center text-text-muted">
                      <BarChart3 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Statistics will be shown here</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Positions & Activity - Right Panel */}
            <div className="w-96 flex flex-col bg-panel">
              {/* Positions Section */}
              <div className="border-b border-border">
                <div className="px-4 py-3 border-b border-border">
                  <h3 className="font-medium text-text-primary">Open Positions</h3>
                </div>
                <div className="p-4 max-h-64 overflow-auto">
                  <table className="trading-table w-full text-xs">
                    <thead>
                      <tr>
                        <th>Symbol</th>
                        <th>Type</th>
                        <th>Volume</th>
                        <th>P/L</th>
                      </tr>
                    </thead>
                    <tbody id="positions-tbody">
                      <tr>
                        <td colSpan={4} className="text-center text-text-muted py-4">
                          No open positions
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Activity Section */}
              <div className="flex-1 flex flex-col">
                <div className="px-4 py-3 border-b border-border">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-text-primary">Activity</h3>
                    <div className="flex gap-1">
                      <button
                        onClick={() => setActivityTab('deals')}
                        className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                          activityTab === 'deals'
                            ? 'bg-primary text-primary-foreground'
                            : 'text-text-secondary hover:text-text-primary'
                        }`}
                      >
                        Deals
                      </button>
                      <button
                        onClick={() => setActivityTab('orders')}
                        className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                          activityTab === 'orders'
                            ? 'bg-primary text-primary-foreground'
                            : 'text-text-secondary hover:text-text-primary'
                        }`}
                      >
                        Orders
                      </button>
                      <button
                        onClick={() => setActivityTab('summary')}
                        className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                          activityTab === 'summary'
                            ? 'bg-primary text-primary-foreground'
                            : 'text-text-secondary hover:text-text-primary'
                        }`}
                      >
                        Summary
                      </button>
                    </div>
                  </div>
                </div>

                {/* Activity Filters */}
                <div className="px-4 py-2 border-b border-border bg-panel-alt">
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      id="historyDateFrom"
                      className="trading-input text-xs"
                      placeholder="From"
                    />
                    <input
                      type="date"
                      id="historyDateTo"
                      className="trading-input text-xs"
                      placeholder="To"
                    />
                  </div>
                  <div className="mt-2">
                    <select id="historySymbolFilter" className="trading-input w-full text-xs">
                      <option value="">All Symbols</option>
                      <option>EURUSD</option>
                      <option>GBPUSD</option>
                      <option>USDJPY</option>
                    </select>
                  </div>
                </div>

                {/* Activity Content */}
                <div className="flex-1 overflow-auto p-4">
                  {activityTab === 'deals' && (
                    <table id="deals-table" className="trading-table w-full text-xs">
                      <thead>
                        <tr>
                          <th>Time</th>
                          <th>Symbol</th>
                          <th>Type</th>
                          <th>Volume</th>
                          <th>Price</th>
                          <th>Profit</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td colSpan={6} className="text-center text-text-muted py-4">
                            No deals found
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  )}
                  
                  {activityTab === 'orders' && (
                    <div>
                      <table id="orders-history-table" className="trading-table w-full text-xs">
                        <thead>
                          <tr>
                            <th>Time</th>
                            <th>Symbol</th>
                            <th>Type</th>
                            <th>Volume</th>
                            <th>Price</th>
                            <th>Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td colSpan={6} className="text-center text-text-muted py-4">
                              No order history
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      
                      {/* Pending Orders Table */}
                      <div className="mt-4">
                        <h4 className="text-xs font-medium text-text-secondary mb-2">Pending Orders</h4>
                        <table className="trading-table w-full text-xs">
                          <thead>
                            <tr>
                              <th>Symbol</th>
                              <th>Type</th>
                              <th>Volume</th>
                              <th>Price</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody id="pending-orders-tbody">
                            <tr>
                              <td colSpan={5} className="text-center text-text-muted py-4">
                                No pending orders
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                  
                  {activityTab === 'summary' && (
                    <div id="history-summary" className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-xs">
                        <div className="bg-card p-3 rounded border border-border">
                          <div className="text-text-secondary">Total Deals</div>
                          <div id="total-deals" className="text-lg font-mono tabular-nums">0</div>
                        </div>
                        <div className="bg-card p-3 rounded border border-border">
                          <div className="text-text-secondary">Total Profit</div>
                          <div id="total-profit" className="text-lg font-mono tabular-nums value-neutral">$0.00</div>
                        </div>
                        <div className="bg-card p-3 rounded border border-border">
                          <div className="text-text-secondary">Commission</div>
                          <div id="total-commission" className="text-lg font-mono tabular-nums">$0.00</div>
                        </div>
                        <div className="bg-card p-3 rounded border border-border">
                          <div className="text-text-secondary">Net Profit</div>
                          <div id="net-profit" className="text-lg font-mono tabular-nums value-neutral">$0.00</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Pending Order Form (Hidden by default, will be shown via JS) */}
      <div id="pending-order-form" className="hidden">
        <div className="grid grid-cols-8 gap-4 items-end">
          <div>
            <label htmlFor="pendingOrderType" className="block text-xs font-medium text-text-secondary mb-1">Order Type</label>
            <select id="pendingOrderType" className="trading-input w-full">
              <option>Buy Limit</option>
              <option>Sell Limit</option>
              <option>Buy Stop</option>
              <option>Sell Stop</option>
            </select>
          </div>
          <div>
            <label htmlFor="pendingSymbol" className="block text-xs font-medium text-text-secondary mb-1">Symbol</label>
            <select id="pendingSymbol" className="trading-input w-full">
              <option>EURUSD</option>
              <option>GBPUSD</option>
              <option>USDJPY</option>
            </select>
          </div>
          <div>
            <label htmlFor="pendingPrice" className="block text-xs font-medium text-text-secondary mb-1">Price</label>
            <input type="number" id="pendingPrice" className="trading-input w-full" step="0.0001" />
          </div>
          <div>
            <label htmlFor="pendingVolume" className="block text-xs font-medium text-text-secondary mb-1">Volume</label>
            <input type="number" id="pendingVolume" className="trading-input w-full" step="0.01" />
          </div>
          <div>
            <label htmlFor="pendingSL" className="block text-xs font-medium text-text-secondary mb-1">Stop Loss</label>
            <input type="number" id="pendingSL" className="trading-input w-full" step="0.0001" />
          </div>
          <div>
            <label htmlFor="pendingTP" className="block text-xs font-medium text-text-secondary mb-1">Take Profit</label>
            <input type="number" id="pendingTP" className="trading-input w-full" step="0.0001" />
          </div>
          <div>
            <label htmlFor="pendingComment" className="block text-xs font-medium text-text-secondary mb-1">Comment</label>
            <input type="text" id="pendingComment" className="trading-input w-full" />
          </div>
          <div>
            <button className="btn-secondary w-full">Place Order</button>
          </div>
        </div>
        <div id="pending-order-output" className="mt-2 text-xs text-text-secondary">
          Ready to place pending order
        </div>
      </div>

      {/* Integrated Pending Order Fields (Alternative approach) */}
      <div id="integrated-pending-fields" className="hidden">
        <select id="pendingOrderTypeIntegrated" className="trading-input">
          <option>Buy Limit</option>
          <option>Sell Limit</option>
          <option>Buy Stop</option>
          <option>Sell Stop</option>
        </select>
        <select id="pendingSymbolIntegrated" className="trading-input">
          <option>EURUSD</option>
        </select>
        <input type="number" id="pendingPriceIntegrated" className="trading-input" step="0.0001" />
        <input type="number" id="pendingVolumeIntegrated" className="trading-input" step="0.01" />
        <input type="number" id="pendingSLIntegrated" className="trading-input" step="0.0001" />
        <input type="number" id="pendingTPIntegrated" className="trading-input" step="0.0001" />
        <div id="pending-order-output-integrated" className="text-xs"></div>
      </div>
    </div>
  );
};

export default TradingDashboard;
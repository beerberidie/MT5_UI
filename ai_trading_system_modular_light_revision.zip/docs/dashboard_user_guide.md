

## Working Active Trades (NEW)

For each open/pending trade, show:
- Current state (entry/exit conditions, strong/weak flags)
- **Confidence trend** (sparkline over last N cycles)
- **Rule compliance** checklist (green/amber/red)
- **Invalidation event** that will close/avoid scaling (from profile)

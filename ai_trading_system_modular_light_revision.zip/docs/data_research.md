

## Session Maps & Date Presets (NEW)

**Sessions (SAST)**
- London: 09:00–17:30
- New York: 14:30–22:00
- Tokyo: 02:00–10:00
- Sydney: 00:00–08:00

**Date presets** for filters/batch evals: Today, Yesterday, Week, Month, Year, Nearly (rolling).

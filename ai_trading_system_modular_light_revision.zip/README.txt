AI Trading System (Light Revision) — rebuilt on 2025-10-06 (SAST)
